﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime;

namespace Calculator_Tutorial___User_Interface
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            textBox1.Text = "1";
            textBox2.Text = "1";
        }

        // numMode parameters
        // ******************
        // 1 for +
        // 2 for -
        // 3 for divide
        // 4 for X
        // ******************

        

        public static class varGroup
        {
            public static int numMode;
            public static int num1;
            public static int num2;
            public static int result;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (varGroup.numMode == 4)
            {
                varGroup.numMode = 1;
            }
            else
            {
                varGroup.numMode++;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            varGroup.numMode = 1;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (varGroup.numMode == 1)
            {
                label1.Text = "+";
            }
            else if (varGroup.numMode == 2)
            {
                label1.Text = "-";
            }
            else if (varGroup.numMode == 3)
            {
                label1.Text = "÷";
            }
            else if (varGroup.numMode == 4)
            {
                label1.Text = "X";
            }

            

            this.Update();
            this.Refresh();
            
            timer1.Interval = 50;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (varGroup.numMode == 1)
            {
                varGroup.result = varGroup.num1 + varGroup.num2;
                textBox3.Text = varGroup.result.ToString();
            }
            else if (varGroup.numMode == 2)
            {
                varGroup.result = varGroup.num1 - varGroup.num2;
                textBox3.Text = varGroup.result.ToString();
            }
            else if (varGroup.numMode == 3)
            {
                varGroup.result = varGroup.num1 / varGroup.num2;
                textBox3.Text = varGroup.result.ToString();
            }
            else if (varGroup.numMode == 4)
            {
                varGroup.result = varGroup.num1 * varGroup.num2;
                textBox3.Text = varGroup.result.ToString();
            }
            else
            {
                // do nothing
            }
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (textBox1.TextLength > 0)
            {
                varGroup.num1 = Int32.Parse(textBox1.Text);
                varGroup.num2 = Int32.Parse(textBox2.Text);
            }
            else if (textBox2.TextLength > 0)
            {
                varGroup.num1 = Int32.Parse(textBox1.Text);
                varGroup.num2 = Int32.Parse(textBox2.Text);
            }
            else if (textBox1.TextLength == 0)
            {
                textBox1.Text = "1";
            }
            else if (textBox2.TextLength == 0)
            {
                textBox1.Text = "1";
            }

            timer2.Interval = 50;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            help Help = new help();
            Help.ShowDialog();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();

            if (true)
            {
                MessageBox.Show("An execution error occured while trying to exit the application. Trying harder.", "Prototype", MessageBoxButtons.OK, MessageBoxIcon.Error);
                System.Environment.Exit(0);
            }
            else
            {

            }
        }

        protected override void WndProc(ref Message m)
        {
            base.WndProc(ref m);
            if (m.Msg == WM_NCHITTEST)
                m.Result = (IntPtr)(HT_CAPTION);
        }

        private const int WM_NCHITTEST = 0x84;
        private const int HT_CLIENT = 0x1;
        private const int HT_CAPTION = 0x2;

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V0.8 - UI Design, V0.8.1.5 - Partial calculating assets, V0.8.4.8 - Fix issues and add all calculations, V0.9 - New help Ui and fix cache issues, new look and feel, 0.9.1.5 - Prototype final", "Changelogs", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
