﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_Tutorial___User_Interface
{
    public partial class help : Form
    {
        public help()
        {
            InitializeComponent();
        }

        private void help_Load(object sender, EventArgs e)
        {
            this.Visible = false;
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            await Task.Delay(500);
            this.Refresh();
            await Task.Delay(500);
            progressBar1.Value = 50;
            await Task.Delay(500);
            this.Update();
            await Task.Delay(500);
            progressBar1.Value = 100;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        
    }
}
